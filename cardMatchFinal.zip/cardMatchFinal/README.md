# matchingGame
# matchingcardgame

This is a Matching Card Game.
Once you've matched 5 pairs of cards of the sae color, you've won the game

![Image description](cardMatchScreen.png)
